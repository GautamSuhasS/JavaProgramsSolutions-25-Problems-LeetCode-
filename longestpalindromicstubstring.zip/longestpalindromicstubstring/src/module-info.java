/**
 * 
 */
/**
 * 
 */
module longestpalindromicstubstring {
}