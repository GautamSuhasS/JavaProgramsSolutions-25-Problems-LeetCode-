/**
 * 
 */
/**
 * 
 */
module reverseinteger {
}