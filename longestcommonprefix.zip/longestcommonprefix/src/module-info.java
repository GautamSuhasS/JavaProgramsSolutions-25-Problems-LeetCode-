/**
 * 
 */
/**
 * 
 */
module longestcommonprefix {
}