package mergeksortedlists;

import java.util.PriorityQueue;
import java.util.Queue;

// Definition for singly-linked list.
class ListNode {
    int val;
    ListNode next;

    // Constructor to create a ListNode with a value
    ListNode() {}
    ListNode(int val) { this.val = val; }
    ListNode(int val, ListNode next) { this.val = val; this.next = next; }
}

class Solution {
    public ListNode mergeKLists(ListNode[] lists) {
        // Create a dummy node to simplify the merging process
        ListNode dummy = new ListNode(0);
        ListNode curr = dummy;

        // Priority queue (min-heap) to get the smallest node at the top
        Queue<ListNode> minHeap = new PriorityQueue<>((a, b) -> Integer.compare(a.val, b.val));

        // Add the head of each list to the priority queue
        for (final ListNode list : lists)
            if (list != null)
                minHeap.offer(list);

        // Merge the lists by repeatedly extracting the smallest node
        while (!minHeap.isEmpty()) {
            ListNode minNode = minHeap.poll();
            if (minNode.next != null)
                minHeap.offer(minNode.next);
            curr.next = minNode;
            curr = curr.next;
        }

        // Return the merged list, starting from the next of the dummy node
        return dummy.next;
    }
}
