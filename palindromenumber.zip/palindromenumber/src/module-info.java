/**
 * 
 */
/**
 * 
 */
module palindromenumber {
}