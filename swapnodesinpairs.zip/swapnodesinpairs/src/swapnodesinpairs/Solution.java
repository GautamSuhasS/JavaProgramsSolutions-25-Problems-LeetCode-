package swapnodesinpairs;
import java.util.*;
//Definition for singly-linked list.
class ListNode {
 int val;
 ListNode next;

 // Constructor to create a ListNode with a value
 ListNode() {}
 ListNode(int val) { this.val = val; }
 ListNode(int val, ListNode next) { this.val = val; this.next = next; }
}

class Solution {
 public ListNode swapPairs(ListNode head) {
     // Get the length of the linked list
     final int length = getLength(head);

     // Dummy node to simplify swapping the first pair
     ListNode dummy = new ListNode(0, head);
     ListNode prev = dummy;
     ListNode curr = head;

     // Swap nodes in pairs
     for (int i = 0; i < length / 2; ++i) {
         ListNode next = curr.next;
         curr.next = next.next;
         next.next = curr;
         prev.next = next;
         prev = curr;
         curr = curr.next;
     }

     return dummy.next;
 }

 // Helper method to calculate the length of the linked list
 private int getLength(ListNode head) {
     int length = 0;
     for (ListNode curr = head; curr != null; curr = curr.next)
         ++length;
     return length;
 }
}
