package reversenodesinkgroup;

//Definition for singly-linked list.
class ListNode {
 int val;
 ListNode next;

 // Constructor to create a ListNode with a value
 ListNode() {}
 ListNode(int val) { this.val = val; }
 ListNode(int val, ListNode next) { this.val = val; this.next = next; }
}

class Solution {
 public ListNode reverseKGroup(ListNode head, int k) {
     // Base case: if the head is null, there's nothing to reverse
     if (head == null)
         return null;

     ListNode tail = head;

     // Check if there are at least k nodes left in the list
     for (int i = 0; i < k; ++i) {
         // If there are less than k nodes remaining, do nothing
         if (tail == null)
             return head;
         tail = tail.next;
     }

     // Reverse the first k nodes and get the new head of the reversed part
     ListNode newHead = reverse(head, tail);

     // Recursively reverse the next group and link it with the current group
     head.next = reverseKGroup(tail, k);

     return newHead;
 }

 // Reverses the nodes between head and tail (not inclusive of tail)
 private ListNode reverse(ListNode head, ListNode tail) {
     ListNode prev = null;
     ListNode curr = head;

     // Reverse the nodes between head and tail
     while (curr != tail) {
         ListNode next = curr.next;
         curr.next = prev;
         prev = curr;
         curr = next;
     }

     return prev;  // prev will be the new head of the reversed section
 }
}
