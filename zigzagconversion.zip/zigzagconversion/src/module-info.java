/**
 * 
 */
/**
 * 
 */
module zigzagconversion {
}