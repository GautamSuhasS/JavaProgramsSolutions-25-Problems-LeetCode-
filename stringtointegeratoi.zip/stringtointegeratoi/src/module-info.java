/**
 * 
 */
/**
 * 
 */
module stringtointegeratoi {
}