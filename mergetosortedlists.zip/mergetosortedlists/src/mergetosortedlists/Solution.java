package mergetosortedlists;
import java.util.*;
//Definition for singly-linked list.
class ListNode {
 int val;
 ListNode next;
 
 // Constructor to create a ListNode with a value
 ListNode() {}
 ListNode(int val) { this.val = val; }
 ListNode(int val, ListNode next) { this.val = val; this.next = next; }
}

class Solution {
 public ListNode mergeTwoLists(ListNode list1, ListNode list2) {
     // Base cases: if one of the lists is null, return the other list
     if (list1 == null || list2 == null)
         return list1 == null ? list2 : list1;

     // Ensure list1 starts with the smaller value
     if (list1.val > list2.val) {
         ListNode temp = list1;
         list1 = list2;
         list2 = temp;
     }

     // Recursively merge the lists
     list1.next = mergeTwoLists(list1.next, list2);
     return list1;
 }
}
